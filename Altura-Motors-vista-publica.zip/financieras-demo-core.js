'use strict';
(function(root){
 function number(value,min,max){if(value===undefined||value===null||String(value).trim()==='')return null;const n=Number(value);return Number.isFinite(n)&&n>=min&&n<=max?n:null}
 function normalize(row){if(!row||typeof row.name!=='string'||!row.name.trim())return null;const rate=number(row.rate,0,1000),minimum=number(row.minimum,0,100),currency=String(row.currency||'').trim().toUpperCase();if(rate===null||minimum===null||!['USD','PEN','COP'].includes(currency))return null;return {id:row.id,nombre:'EJEMPLO · '+row.name.trim().slice(0,120),moneda:currency,tea:rate,plazo_min:1,plazo_max:360,inicial_min:minimum,condiciones:'Condiciones de prueba. '+String(row.conditions||'').slice(0,1000)}}
 const api={normalize};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaDemoFinance=api;
})(typeof window!=='undefined'?window:globalThis);
