// Al crear tu proyecto, coloca SOLO la URL del proyecto y la clave publicable/anon.
// Nunca coloques aquí una clave secret ni service_role.
window.ALTURA_CONFIG = { url: '', publicKey: '', whatsappNumber: '51977122757' };
