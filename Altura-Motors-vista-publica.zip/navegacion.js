'use strict';
// Se ejecuta después de los módulos originales: conserva sus controles y separa las vistas.
(()=>{
  const segment=(location.pathname.split('/').filter(Boolean).pop()||'index').toLowerCase();
  const page=segment.endsWith('.html')?segment:segment+'.html';
  const views={'index.html':'inicio','vehiculos.html':'catalogo','comparador.html':'comparador','contacto.html':'contacto','nosotros.html':'nosotros'};
  const view=views[page]||'inicio';
  const main=document.querySelector('main');
  const showMore=document.querySelector('#more');if(showMore)showMore.textContent='Mostrar más vehículos →';
  const hero=main.querySelector('.hero'), finder=main.querySelector('.finder'), catalog=main.querySelector('#catalogo'), why=main.querySelector('.why'), trust=main.querySelector('#confianza'), finance=main.querySelector('#financiamiento'), appointment=main.querySelector('#agenda'), extra=main.querySelector('.extra');
  const show=(element,visible)=>{if(element)element.hidden=!visible};
  show(hero,view==='inicio'); show(finder,view==='inicio'||view==='catalogo'); show(catalog,view==='inicio'||view==='catalogo'); show(why,view==='nosotros'); show(trust,view==='nosotros'); show(finance,false); show(appointment,view==='contacto'); show(extra,view==='comparador'||view==='contacto');
  if(extra && view==='comparador'){extra.querySelectorAll('.extra-grid,.alert-form,.faq').forEach(el=>el.hidden=true)}
  if(extra && view==='contacto'){extra.querySelectorAll('.title,#selectors,#comparison').forEach(el=>el.hidden=true);const intro=extra.querySelector(':scope > p');if(intro)intro.hidden=true}
  document.querySelectorAll('a[href="#inicio"]').forEach(a=>a.href='index.html');
  document.querySelectorAll('a[href="#catalogo"]').forEach(a=>a.href='vehiculos.html');
  document.querySelectorAll('a[href="#confianza"]').forEach(a=>a.href='nosotros.html');
  document.querySelectorAll('a[href="#financiamiento"]').forEach(a=>a.href='financiamiento.html');
  document.querySelectorAll('a[href="#agenda"]').forEach(a=>a.href='contacto.html');
  const nav=document.querySelector('#nav'); const comparison=document.createElement('a'); comparison.href='comparador.html';comparison.textContent='Comparador';nav.insertBefore(comparison,nav.lastElementChild);
  if(!window.ALTURA_CONFIG?.url&&!window.ALTURA_CONFIG?.publicKey){const banner=document.createElement('div');banner.className='demo-public-banner';banner.textContent='CATÁLOGO DE REFERENCIA · Información de prueba; confirma disponibilidad y condiciones.';document.body.prepend(banner);const favorites=document.createElement('a');favorites.href='favoritos-demo.html';favorites.textContent='Favoritos';nav.append(favorites)}
  const adminButton=document.querySelector('#adminOpen');if(adminButton)adminButton.hidden=true;
  if(view==='inicio'){const more=document.createElement('a');more.href='vehiculos.html';more.className='btn gold';more.textContent='Ir al catálogo →';catalog.append(more)}
  if(view==='catalogo'){const title=document.createElement('div');title.className='section';title.innerHTML='<small>EXPLORA EL INVENTARIO</small><h1>Encuentra tu próximo vehículo.</h1><div class="catalog-extra-filters"><label>Buscar marca o modelo<input id="catalogSearch" type="search" placeholder="Buscar vehículos"></label><label>Año desde<input id="catalogYear" type="number" min="1900" max="2100" placeholder="Ej. 2020"></label><label>Transmisión<select id="catalogTransmission"><option value="">Todas</option><option value="automática">Automática</option><option value="manual">Manual</option></select></label></div>';main.prepend(title);title.querySelectorAll('input,select').forEach(el=>el.addEventListener('input',()=>{all=true;render()}))}
  if(view==='contacto'){const intro=document.createElement('section'),eyebrow=document.createElement('small'),heading=document.createElement('h1'),description=document.createElement('p');intro.className='section contacto-intro';eyebrow.textContent='HABLEMOS DE TU PRÓXIMO VEHÍCULO';heading.textContent='Estamos para orientarte.';description.textContent='Cuéntanos qué estás buscando, consulta por financiamiento o comparte los datos de tu vehículo para una evaluación.';intro.append(eyebrow,heading,description);const url=window.AlturaContact?.link('Hola, quiero información sobre vehículos en Altura Motors.');if(url){const link=document.createElement('a');link.className='btn gold';link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Escríbenos por WhatsApp →';intro.append(link)}else{const info=document.createElement('p');info.textContent='Contacto por WhatsApp pendiente de configuración.';intro.append(info)}main.prepend(intro)}
  if(view==='comparador'){const selectors=document.querySelector('#selectors');if(!selectors.children.length){const empty=document.createElement('p');empty.textContent='Cuando haya vehículos publicados podrás seleccionarlos para compararlos.';selectors.append(empty)}}
})();
