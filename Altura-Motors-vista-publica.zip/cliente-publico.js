'use strict';
(()=>{for(const link of document.querySelectorAll('a[href="demo-admin.html"]'))link.hidden=true})();
