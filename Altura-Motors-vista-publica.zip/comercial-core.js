'use strict';
(function(root){
 function createDemo(db,makeId,now){return{
  availableVehicles(){return db.list('vehicles').filter(x=>x.state==='Publicado')},
  quote({vehicleId,customer,contact}){
   customer=String(customer||'').trim();contact=String(contact||'').trim();if(!customer||customer.length>120||contact.length>200)throw new Error('Revisa los datos de prueba.');
   return db.transaction(data=>{const vehicle=data.vehicles.find(x=>x.id===vehicleId&&x.state==='Publicado');if(!vehicle)throw new Error('El vehículo ya no está publicado para esta prueba.');const amount=Number(vehicle.price);if(!Number.isFinite(amount)||amount<0||vehicle.price===''||vehicle.price==null)throw new Error('El vehículo no tiene un precio de prueba válido.');const date=now(),quoteId=makeId(),opportunityId=makeId(),label=[vehicle.brand,vehicle.model].filter(Boolean).join(' ');const quote={id:quoteId,name:'Cotización de prueba',vehicleId:vehicle.id,vehicle:label,customer,contact,price:String(amount),opportunityId,state:'Borrador',createdAt:date};const opportunity={id:opportunityId,name:customer,contact,interest:label,vehicleId:vehicle.id,quoteId,stage:'Nuevo contacto',state:'Borrador',createdAt:date};data.quotes.push(quote);data.opportunities.push(opportunity);return quote});
  },
  reserve({vehicleId,customer,date,time,branch}){
   customer=String(customer||'').trim();date=String(date||'');time=String(time||'');branch=String(branch||'').trim();
   if(!customer||customer.length>120||branch.length>120||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw new Error('Revisa los datos de la solicitud de prueba.');
   const parsed=new Date(date+'T00:00:00Z');if(!Number.isFinite(parsed.valueOf())||parsed.toISOString().slice(0,10)!==date)throw new Error('La fecha no es válida.');
   return db.transaction(data=>{const vehicle=data.vehicles.find(x=>x.id===vehicleId&&x.state==='Publicado');if(!vehicle)throw new Error('El vehículo ya no está publicado para esta prueba.');if(data.appointments.some(x=>x.vehicleId===vehicleId&&x.date===date&&x.time===time&&!['Cancelada','Completada'].includes(x.bookingStatus)))throw new Error('Ya existe una solicitud de prueba para este vehículo y horario.');const timestamp=now(),id=makeId(),opportunityId=makeId(),label=[vehicle.brand,vehicle.model].filter(Boolean).join(' '),booking={id,name:'Prueba de manejo simulada',vehicleId,vehicle:label,customer,date,time,branch,bookingStatus:'Pendiente',opportunityId,state:'Borrador',createdAt:timestamp};data.appointments.push(booking);data.opportunities.push({id:opportunityId,name:customer,interest:label,vehicleId,appointmentId:id,stage:'Nuevo contacto',state:'Borrador',createdAt:timestamp});return booking});
  }
 }}
 const api={createDemo};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaCommercial=api;
})(typeof window!=='undefined'?window:globalThis);
