'use strict';
(function(root){
 function simulate({price,down,months,annualRate}){
  if(!Number.isFinite(price)||price<=0||!Number.isFinite(down)||down<0||down>=price||!Number.isInteger(months)||months<1||months>360||!Number.isFinite(annualRate)||annualRate<0||annualRate>1000)throw new RangeError('Parámetros financieros inválidos');
  const principal=price-down,rate=Math.expm1(Math.log1p(annualRate/100)/12),payment=rate===0?principal/months:principal*rate/(-Math.expm1(-months*Math.log1p(rate)));let balance=principal,interestTotal=0;const schedule=[];
  for(let month=1;month<=months;month++){const interest=balance*rate,capital=month===months?balance:Math.min(balance,payment-interest),installment=capital+interest;balance=Math.max(0,balance-capital);interestTotal+=interest;schedule.push({month,installment,interest,capital,balance})}
  return {principal,monthlyRate:rate,payment,interestTotal,total:principal+interestTotal,schedule};
 }
 const api={simulate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaFinance=api;
})(typeof window!=='undefined'?window:globalThis);
