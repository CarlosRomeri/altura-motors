'use strict';
(function(root){
 function published(records){
  if(!Array.isArray(records))return [];
  const clean=(value,max)=>typeof value==='string'?value.trim().slice(0,max):'';
  return records.filter(x=>x&&x.state==='Publicado'&&clean(x.name,120)).slice(0,50).map(x=>{
   let social='';try{const u=new URL(clean(x.social,2048));if(u.protocol==='https:'&&!u.username&&!u.password)social=u.href}catch{}
   return {name:clean(x.name,120),address:clean(x.address,250),hours:clean(x.hours,200),phone:clean(x.phone,80),email:clean(x.email,180),social};
  });
 }
 if(typeof module!=='undefined'&&module.exports){module.exports={published};return}
 const cfg=root.ALTURA_CONFIG;if(cfg&&(cfg.url||cfg.publicKey))return;
 let contacts;try{contacts=published(root.AlturaDemoStore.list('contacts'))}catch{return}if(!contacts.length)return;
 const main=document.querySelector('main');if(!main)return;
 const section=document.createElement('section');section.className='section demo-contacts';
 const label=document.createElement('small');label.textContent='DATOS FICTICIOS · DEMOSTRACIÓN LOCAL';
 const heading=document.createElement('h2');heading.textContent='Contactos y sucursales de prueba';
 const notice=document.createElement('p');notice.textContent='Información guardada únicamente en este navegador; no corresponde a datos comerciales verificados.';
 section.append(label,heading,notice);
 for(const contact of contacts){const article=document.createElement('article'),title=document.createElement('h3');title.textContent=contact.name;article.append(title);
  for(const [label,value] of [['Dirección',contact.address],['Horario',contact.hours],['Teléfono',contact.phone],['Correo',contact.email]])if(value){const p=document.createElement('p');p.textContent=label+': '+value;article.append(p)}
  if(contact.social){const a=document.createElement('a');a.href=contact.social;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Red social de prueba ↗';article.append(a)}section.append(article)
 }
 main.append(section);
})(typeof window!=='undefined'?window:globalThis);
