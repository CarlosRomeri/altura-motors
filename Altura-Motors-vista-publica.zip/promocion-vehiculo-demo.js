'use strict';
(()=>{
 const id=new URLSearchParams(location.search).get('id'),target=document.querySelector('#price');if(!id||!target||!window.AlturaPromotions)return;
 let vehicle,campaigns;try{vehicle=window.AlturaDemoStore.list('vehicles').find(v=>v.id===id&&v.state==='Publicado');campaigns=window.AlturaPromotions.active(window.AlturaDemoStore.list('campaigns'),window.AlturaPromotions.limaToday(new Date())).filter(c=>c.vehicleId===id)}catch{return}if(!vehicle||!campaigns.length)return;
 const section=document.createElement('section');section.className='notice';const heading=document.createElement('strong');heading.textContent='Promociones ficticias para este vehículo';section.append(heading);
 for(const campaign of campaigns){const p=document.createElement('p');p.textContent=campaign.name+(campaign.body?' · '+campaign.body:'')+(campaign.end?' · Vigente en esta prueba hasta '+campaign.end:'');section.append(p)}
 const note=document.createElement('p');note.textContent='Información de demostración: no es una oferta real y no modifica el precio de la cotización.';section.append(note);target.after(section);
})();
