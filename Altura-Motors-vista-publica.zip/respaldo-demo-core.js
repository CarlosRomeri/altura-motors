'use strict';
(function(root){
 const collections=['vehicles','finance','content','contacts','opportunities','tasks','quotes','appointments','appraisals','sales','campaigns','favorites'];
 function validate(data){
  if(!data||typeof data!=='object'||Array.isArray(data)||data.format!=='altura-demo-backup'||data.version!==1||!data.collections||typeof data.collections!=='object'||Array.isArray(data.collections))throw Error('El archivo no es un respaldo compatible.');
  for(const key of collections){const rows=data.collections[key];if(!Array.isArray(rows)||rows.length>10000)throw Error('Colección inválida o demasiado grande: '+key);const seen=new Set();for(const record of rows){if(!record||typeof record!=='object'||Array.isArray(record)||typeof record.id!=='string'||!record.id.trim()||record.id.length>200||seen.has(record.id))throw Error('Hay registros inválidos o duplicados en '+key+'.');seen.add(record.id)}}
  return data;
 }
 function exportData(store,now){const data={format:'altura-demo-backup',version:1,exportedAt:now,collections:{}};for(const key of collections)data.collections[key]=store.list(key);return validate(data)}
 function restore(store,data){validate(data);store.transaction(current=>{for(const key of collections)current[key]=data.collections[key]})}
 const api={collections,validate,exportData,restore};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaDemoBackup=api;
})(typeof window!=='undefined'?window:globalThis);
