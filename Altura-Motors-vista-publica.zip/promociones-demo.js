'use strict';
(function(root){
 function dateValid(v){if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v))return false;const d=new Date(v+'T00:00:00Z');return Number.isFinite(d.valueOf())&&d.toISOString().slice(0,10)===v}
 function active(records,today){if(!Array.isArray(records)||!dateValid(today))return [];const text=(v,n)=>typeof v==='string'?v.trim().slice(0,n):'';return records.filter(r=>r&&r.state==='Publicado'&&text(r.name,120)&&(!r.start||dateValid(r.start)&&r.start<=today)&&(!r.end||dateValid(r.end)&&r.end>=today)&&(!r.start||!r.end||r.start<=r.end)).slice(0,50).map(r=>{let image='';try{const u=new URL(text(r.image,2048));if(u.protocol==='https:'&&!u.username&&!u.password)image=u.href}catch{}return {name:text(r.name,120),body:text(r.body,1200),start:r.start||'',end:r.end||'',image,vehicleId:text(r.vehicleId,200)}})}
 function limaToday(now){const p=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Lima',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);const get=k=>p.find(x=>x.type===k).value;return `${get('year')}-${get('month')}-${get('day')}`}
 if(typeof module!=='undefined'&&module.exports){module.exports={dateValid,active,limaToday};return}root.AlturaPromotions={active,limaToday};
 const cfg=root.ALTURA_CONFIG;if(cfg&&(cfg.url||cfg.publicKey))return;
 let records;try{records=active(root.AlturaDemoStore.list('campaigns'),limaToday(new Date())).filter(x=>!x.vehicleId)}catch{return}if(!records.length)return;
 const catalog=document.querySelector('#catalogo');if(!catalog)return;
 const section=document.createElement('section');section.className='demo-promotions';
 const title=document.createElement('h2');title.textContent='Promociones de prueba';
 const intro=document.createElement('p');intro.textContent='Ejemplos ficticios guardados en este navegador. No son ofertas reales y no modifican el precio de las cotizaciones.';section.append(title,intro);
 for(const item of records){const article=document.createElement('article'),heading=document.createElement('h3');heading.textContent=item.name;article.append(heading);if(item.body){const p=document.createElement('p');p.textContent=item.body;article.append(p)}if(item.start||item.end){const p=document.createElement('p');p.textContent='Vigencia de prueba: '+(item.start||'sin inicio')+' → '+(item.end||'sin fin');article.append(p)}if(item.image){const img=document.createElement('img');img.src=item.image;img.alt='Imagen de promoción ficticia';img.loading='lazy';img.style.maxWidth='min(100%, 360px)';article.append(img)}section.append(article)}catalog.append(section);
})(typeof window!=='undefined'?window:globalThis);
