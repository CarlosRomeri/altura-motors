'use strict';
(function(root){
 function keyType(key){
  if(typeof key!=='string'||key.length>4096)return '';
  if(/^sb_publishable_[A-Za-z0-9_-]+$/.test(key))return 'publishable';
  const parts=key.split('.');if(parts.length!==3||parts.some(x=>!x||!/^[A-Za-z0-9_-]+$/.test(x)))return '';
  try{const part=parts[1].replace(/-/g,'+').replace(/_/g,'/'),payload=JSON.parse(atob(part+'='.repeat((4-part.length%4)%4)));return payload.role==='anon'?'legacy-anon':''}catch{return ''}
 }
 function validate(config){try{if(!config||typeof config.url!=='string'||!keyType(config.publicKey))return false;const url=new URL(config.url);return url.protocol==='https:'&&!url.username&&!url.password&&url.pathname==='/'&&!url.search&&!url.hash}catch{return false}}
 function headers(config,token){if(!validate(config))throw Error('Configuración de Supabase inválida.');const h={apikey:config.publicKey};if(token)h.Authorization='Bearer '+token;else if(keyType(config.publicKey)==='legacy-anon')h.Authorization='Bearer '+config.publicKey;return h}
 const api={keyType,validate,headers};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaSupabaseConfig=api;
})(typeof window!=='undefined'?window:globalThis);
