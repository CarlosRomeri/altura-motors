'use strict';
(function(root){
 function select(records,name='inicio'){
  if(!Array.isArray(records))return null;
  const candidates=records.filter(r=>r&&r.state==='Publicado'&&typeof r.name==='string'&&r.name.trim().toLocaleLowerCase('es')===name.toLocaleLowerCase('es')&&typeof r.updatedAt==='string'&&Number.isFinite(Date.parse(r.updatedAt)));
  candidates.sort((a,b)=>Date.parse(b.updatedAt)-Date.parse(a.updatedAt)||String(a.id||'').localeCompare(String(b.id||'')));
  const r=candidates[0];if(!r)return null;
  const clean=(v,n)=>typeof v==='string'?v.trim().slice(0,n):'';
  let image='';try{const value=clean(r.image,2048);const u=new URL(value);if(u.protocol==='https:'&&!u.username&&!u.password&&!/["'()\\]/.test(u.href))image=u.href}catch{}
  const accent=clean(r.accent,7);
  return {headline:clean(r.headline,180),body:clean(r.body,600),image,accent:/^#[0-9a-f]{6}$/i.test(accent)?accent:''};
 }
 if(typeof module!=='undefined'&&module.exports){module.exports={select};return}
 const cfg=root.ALTURA_CONFIG;if(cfg&&(cfg.url||cfg.publicKey))return;
 let records;try{records=root.AlturaDemoStore.list('content')}catch{return}
 const put=(selector,value)=>{const e=document.querySelector(selector);if(e&&value)e.textContent=value};
 const start=select(records,'Inicio');if(start){put('.heroCopy h1',start.headline);put('.heroCopy p',start.body);const hero=document.querySelector('.hero');if(hero&&start.image)hero.style.backgroundImage='linear-gradient(90deg,rgba(0,0,0,.78),rgba(0,0,0,.18)),url("'+start.image+'")';if(start.accent)document.documentElement.style.setProperty('--gold',start.accent)}
 const about=select(records,'Nosotros');if(about){put('.why h2',about.headline);put('.why p',about.body);const img=document.querySelector('.whyImg');if(img&&about.image)img.style.backgroundImage='url("'+about.image+'")'}
 const contact=select(records,'Contacto');if(contact){put('#agenda h2',contact.headline);put('#agenda p',contact.body)}
 const footer=select(records,'Pie');if(footer)put('footer > p',footer.body);
 for(let i=1;i<=3;i++){const item=select(records,'Confianza '+i);if(item){put('.trustList article:nth-child('+i+') h3',item.headline);put('.trustList article:nth-child('+i+') p',item.body)}}
})(typeof window!=='undefined'?window:globalThis);
