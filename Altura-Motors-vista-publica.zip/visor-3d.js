'use strict';
(()=>{
 let libraryRequested=false;
 document.querySelector('#cars').addEventListener('click',event=>{
  const card=event.target.closest('[data-car]');if(!card)return;const car=data.find(x=>x.id===Number(card.dataset.car));if(!car||!car.model3d)return;
  let url;try{url=new URL(car.model3d);if(url.protocol!=='https:'||!url.pathname.toLowerCase().endsWith('.glb'))return}catch{return}
  const target=document.querySelector('#modalInfo'),section=document.createElement('section'),title=document.createElement('h3'),message=document.createElement('p'),viewer=document.createElement('model-viewer');title.textContent='Vista 3D';message.textContent='Cargando modelo 3D…';message.setAttribute('role','status');viewer.setAttribute('src',url.href);viewer.setAttribute('alt','Modelo 3D de '+car.b+' '+car.m);viewer.setAttribute('camera-controls','');viewer.setAttribute('touch-action','pan-y');viewer.setAttribute('loading','lazy');viewer.addEventListener('load',()=>{message.textContent='Arrastra para girar el modelo; usa el gesto de zoom para acercarlo.'});viewer.addEventListener('error',()=>{message.textContent='No se pudo cargar el modelo 3D. Comprueba el archivo y sus permisos de acceso.'});section.className='model3d-section';section.append(title,message,viewer);target.prepend(section);
  if(!libraryRequested){libraryRequested=true;const script=document.createElement('script');script.type='module';script.src='https://ajax.googleapis.com/ajax/libs/model-viewer/4.4.0/model-viewer.min.js';script.addEventListener('error',()=>{message.textContent='No se pudo cargar el visor 3D. Comprueba la conexión.'});document.head.append(script)}
 });
})();
