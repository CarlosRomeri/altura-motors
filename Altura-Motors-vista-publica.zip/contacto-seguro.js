'use strict';
(function(root){
 function link(config,message){const number=String(config?.whatsappNumber||'').trim();if(!/^[1-9]\d{7,14}$/.test(number))return '';return 'https://wa.me/'+number+(message?'?text='+encodeURIComponent(String(message).slice(0,4000)):'')}
 if(typeof module!=='undefined'&&module.exports){module.exports={link};return}
 root.AlturaContact={link:message=>link(root.ALTURA_CONFIG,message),open(message){const url=link(root.ALTURA_CONFIG,message);if(!url){root.alert('El contacto por WhatsApp aún no está configurado. Esta prueba no envió datos.');return false}root.open(url,'_blank','noopener,noreferrer');return true}};
 const button=document.querySelector('a.wa');if(button){const url=link(root.ALTURA_CONFIG,'');if(url){button.href=url;button.rel='noopener noreferrer';button.hidden=false}else button.hidden=true}
})(typeof window!=='undefined'?window:globalThis);
