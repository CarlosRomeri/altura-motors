'use strict';
(function(root){function normalize(value){return ['SUV','Pickup','Sedán','Comercial'].includes(value)?value:'SUV'}const api={normalize};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Altura3DCategories=api})(typeof window!=='undefined'?window:globalThis);
