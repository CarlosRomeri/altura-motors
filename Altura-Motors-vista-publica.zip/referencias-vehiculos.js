'use strict';
(function(root){
 // Las fotografías son ilustrativas y pueden representar otra versión o mercado.
 const refs={
  'toyota-hilux':['2021 Toyota HiLux IMG 3883.jpg','Alexander Migl','4.0','Pickup orientada a trabajo, transporte de carga y viajes fuera del asfalto según la versión. Comprueba capacidad de carga y tracción de la unidad.'],
  'jetour-x70':['Jetour X70 003.jpg','Jengtingchen','4.0','SUV enfocada en traslados familiares y viajes; verifica número de asientos y equipamiento de la versión.'],
  'toyota-rush':['2018 Toyota Rush 1.5S.jpg','Chanokchon','4.0','SUV de siete plazas en la versión documentada, útil para desplazamientos familiares; revisa espacio de carga con todas las filas en uso.'],
  'ford-territory':['2023 Ford Territory (China), front 8.3.23.jpg','Kevauto','4.0','SUV de cinco plazas que puede encajar en trayectos urbanos y viajes familiares; compara dimensiones y equipamiento por versión.'],
  'toyota-yaris-cross':['2023 Toyota Yaris Cross ASEAN 1.jpg','Mocarey15','4.0','SUV para desplazamientos cotidianos y viajes; la fotografía es de otro mercado y no identifica la versión técnica peruana.'],
  'kia-soluto':['Kia Soluto AB 1.4 EX AT Clear White.jpg','Ethan Llamas','4.0','Sedán para traslados diarios y uso urbano; conviene revisar transmisión, equipamiento y maletero de la unidad concreta.'],
  'hyundai-grand-i10':['Hyundai Grand i10 Sedan 2022 (53703857804).jpg','RL GNZLZ','2.0','Sedán compacto para ciudad y desplazamientos cotidianos; la ficha de referencia indica 402 L de maletero para la versión citada.'],
  'chevrolet-n400':['2021 Chevrolet N400 Max (Chile) front view.jpg','RL GNZLZ','2.0','Vehículo comercial de dos plazas destinado al transporte de mercancías; verifica peso y volumen admitidos para el trabajo previsto.']
 };
 function find(id){if(typeof id!=='string'||!id.startsWith('ficha-peru-v1-'))return null;const slug=id.slice('ficha-peru-v1-'.length),data=refs[slug];if(!data)return null;const [file,author,version,use]=data,encoded=encodeURIComponent(file).replace(/\(/g,'%28').replace(/\)/g,'%29');return {image:'imagenes-referencia/'+slug+'.jpg',source:'https://commons.wikimedia.org/wiki/File:'+encoded,author,license:'CC BY-SA '+version,licenseUrl:'https://creativecommons.org/licenses/by-sa/'+version+'/',use}}
 if(typeof module!=='undefined'&&module.exports)module.exports={find};else root.AlturaVehicleReferences={find};
})(typeof window!=='undefined'?window:globalThis);
