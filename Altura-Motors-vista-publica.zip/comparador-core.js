'use strict';
(function(root){
 function value(v){return v===null||v===undefined||String(v).trim()===''?'Por definir':String(v)}
 function rows(cars){return [
  ['Vehículo',c=>[c.b,c.m].filter(Boolean).join(' ')],
  ['Tipo de carrocería',c=>value(c.t)],
  ['Año',c=>Number.isFinite(c.y)&&c.y>0?String(c.y):'Por definir'],
  ['Precio',c=>Number.isFinite(c.p)?new Intl.NumberFormat('es-PE',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(c.p):'Por definir'],
  ['Kilometraje',c=>Number.isFinite(c.k)?c.k.toLocaleString('es-PE')+' km':'Por definir'],
  ['Transmisión',c=>value(c.transmission)],['Combustible',c=>value(c.fuel)],
  ['Disponibilidad',c=>value(c.s)],['Datos técnicos y equipamiento',c=>value(c.features)],
  ['Orientación de uso',c=>value(c.photoCredit?.use||c.referenceUse)]
 ].map(([label,get])=>({label,values:cars.map(get)}))}
 const api={rows};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AlturaCompare=api;
})(typeof window!=='undefined'?window:globalThis);
